package com.cg;

/**
 * @author adsupe
 *
 */
public enum CreditDebit {

	CR,DR;
}
